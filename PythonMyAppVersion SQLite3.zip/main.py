
import pymysql

db = pymysql.connect("141.136.33.245", "fundoame", "Compuclinica123@", "fundoame_DBtienda")

cursor = db.cursor()

cursor.execute("select * from user_registration")

data = cursor.fetchone()
print("Database version : {0}".format(data))

db.close()



