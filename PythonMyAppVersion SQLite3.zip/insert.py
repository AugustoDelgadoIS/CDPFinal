import pymysql

db = pymysql.connect("141.136.33.245", "fundoame", "Compuclinica123@", "fundoame_DBtienda")
cursor = db.cursor()

sql = "INSERT INTO user_registration(id, email,password) \
   VALUES (NULL,'{0}','{1}')".format('moroni@gmail.com', '123456')

try:

    cursor.execute(sql)

    db.commit()

except:

    db.rollback()

db.close()



